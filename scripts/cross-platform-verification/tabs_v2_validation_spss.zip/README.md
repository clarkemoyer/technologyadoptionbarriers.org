# TABS V2 Validation - SPSS Bundle

This zip contains everything an SPSS user needs to independently reproduce
the TABS validation pipeline on the same frozen N=200 dataset that drives
the canonical Python and R analyses.  Sections 1–12 cover descriptives,
reliability, factor analysis, correlations, group comparisons, and missing-
data diagnostics using built-in SPSS procedures.  Sections 13–14 extend
the validation with CFA, SEM, and measurement-invariance tests via embedded
Python (semopy) and embedded R (lavaan/semTools).

## Quick start - one double-click

1. Unzip into any folder (Desktop, Documents, anywhere).
2. Double-click the launcher for your operating system:
   - **Windows**: `0_DOUBLE_CLICK_ME_TO_START_WINDOWS.bat`
   - **macOS**: right-click `0_DOUBLE_CLICK_ME_TO_START_MAC.command` -> Open (one-time
     Gatekeeper prompt). After the first run, double-click works.
3. SPSS opens with the syntax preloaded; click **Run → All** inside SPSS.
4. After ~90 seconds, open `spv_export.xlsx` in this folder.

The launcher locates SPSS automatically and opens it with the syntax
file preloaded. Two result files are written into the same folder you
extracted the zip to once SPSS finishes running:

- `spv_export.xlsx` - all SPSS tables in Excel format
- `Post_Run_Results.spv` - native SPSS Viewer document (open with SPSS or
  the free IBM SPSS SmartReader)

## Manual fallback (if the launcher cannot find SPSS)

1. Open `tabs_v2_validation.sps` in SPSS (`File -> Open -> Syntax`).
2. `Run -> All`. Output appears in a new Viewer document.
3. The syntax automatically writes `spv_export.xlsx` and `Post_Run_Results.spv`
   into the folder where the .sps file lives.

If SPSS reports "File not found" for the .sav, set the working directory
to the unzipped folder via `Edit -> Options -> File Locations`.

## Targeted SPSS license

Tested on IBM SPSS Statistics 31.0; expected to work on 24+ with
Statistics Base, Regression, Bootstrapping, Missing Values, and
Advanced Statistics.

Sections 1–12 use only built-in SPSS procedures (descriptives,
reliability, factor analysis, correlations, MVA). Sections 13–14 extend
the validation via embedded Python (`semopy==2.3.11`) and embedded R
(`lavaan`/`semTools`): `semopy` is installed automatically on first run;
R packages (`lavaan`, `semTools`) are optional and installed only after
the launcher prompts for confirmation.

- **Section 13** (Python/semopy): CFA fit indices, McDonald's omega,
  composite reliability, AVE, HTMT/HTMT2, **bifactor decomposition**
  (omega-h, omega-total, ECV) for the Barriers construct, Mardia
  multivariate normality, multigroup CFA configural baseline.
- **Section 14** (R/lavaan): metric and scalar measurement-invariance
  Delta-CFI tests by org-size group, plus McDonald's omega cross-check
  via semTools::reliability().

IBM SPSS Amos is **not** required. IRT GRM, second-order CFA, and ESEM
with target rotation remain in the separate Python pipeline
(`tabs_v2_validation_python.zip`); semopy does not have first-class
support for those, and the canonical pipeline already provides them.

## What's inside

```
0_DOUBLE_CLICK_ME_TO_START_WINDOWS.bat  <- Windows double-click launcher
0_DOUBLE_CLICK_ME_TO_START_MAC.command  <- macOS double-click launcher
tabs_v2_crp200_spss.sav     <- SPSS native binary worksheet
tabs_v2_crp200_spss.csv     <- same data, CSV form (for re-import elsewhere)
tabs_v2_validation.sps      <- syntax file (loaded into SPSS by the launcher; click Run → All)
README_SPSS.md              <- detailed walkthrough + expected values
README.md                   <- this file
```

## Three quick spot-checks that should match exactly

| Stat | Expected |
|---|---|
| Cronbach's alpha (Barriers, 18 items) | 0.873 |
| Cronbach's alpha (Readiness, 17 items) | 0.917 |
| Cronbach's alpha (Maturity, 8 items) | 0.885 |
| Listwise N (Barriers / Readiness / Maturity) | 192 / 181 / 191 |

If any of these disagree with what SPSS prints, the data import is off
(usually missing-value coding); resolve before interpreting anything else.

See `README_SPSS.md` for the complete expected-value table and the menu
paths for KMO + Bartlett (GUI-only options on the Factor Analysis dialog).
