# TABS V2 Validation - Minitab Bundle

This zip contains everything a Minitab user needs to independently reproduce
the descriptive + reliability layer of the TABS validation pipeline on the
same frozen N=200 dataset that drives the canonical Python and R analyses.

## Quick start (about 3 clicks once Minitab is open)

1. Unzip into any folder.
2. `File -> Open Worksheet -> tabs_v2_crp200_minitab.csv`
3. `File -> Run an Exec -> tabs_v2_validation.MTB -> Run 1 time`

KMO and Bartlett's sphericity are GUI-only options on Minitab's Factor
Analysis dialog (no session subcommand). To see them, run the Factor
Analysis block manually from the menu and check the boxes in `Options...`.

## Scope

Minitab covers the descriptive + reliability layer (Cronbach alpha, KMO,
Bartlett, EFA, inter-construct correlations, 2-sample t, Mahalanobis
outliers). It does NOT have native CFA, so McDonald's omega from CFA,
composite reliability with SEs, AVE, HTMT/HTMT2, bifactor models,
second-order CFA, multigroup CFA, measurement invariance, ESEM, IRT GRM,
and Mardia normality stay in the Python pipeline (download
`tabs_v2_validation_python.zip` for those).

## What's inside

```
tabs_v2_crp200_minitab.csv  <- pre-encoded numeric data (B1-B18, R1-R17, M1-M8)
tabs_v2_validation.MTB      <- Minitab Exec macro (Run an Exec)
README_MINITAB.md           <- detailed walkthrough + expected values
```

## Three quick spot-checks that should match exactly

| Stat | Expected |
|---|---|
| Cronbach's alpha (Barriers, 18 items) | 0.873 |
| Cronbach's alpha (Readiness, 17 items) | 0.917 |
| Cronbach's alpha (Maturity, 8 items) | 0.885 |
| Listwise N (Barriers / Readiness / Maturity) | 192 / 181 / 191 |

See `README_MINITAB.md` for the complete expected-value table and the
manual-from-EFA-loadings formulas for omega, CR, and AVE in Calc -> Calculator.
