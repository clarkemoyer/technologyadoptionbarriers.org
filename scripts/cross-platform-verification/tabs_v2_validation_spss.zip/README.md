# TABS V2 Validation - SPSS Bundle

This zip contains everything an SPSS user needs to independently reproduce
the descriptive + reliability layer of the TABS validation pipeline on the
same frozen N=200 dataset that drives the canonical Python and R analyses.

## Quick start (about 2 clicks once SPSS is open)

1. Unzip into any folder.
2. Open `tabs_v2_validation.sps` in SPSS (`File -> Open -> Syntax`).
3. `Run -> All`. Output appears in a new Viewer document.

If SPSS reports "File not found" for the .sav, set the working directory
to the unzipped folder via `Edit -> Options -> File Locations`.

## Targeted SPSS license

Built for IBM SPSS Statistics 31.0 with Statistics Base + Regression +
Bootstrapping + Missing Values + Advanced Statistics. Without IBM SPSS
Amos, this bundle covers the descriptive + reliability layer only - CFA
fit indices, McDonald's omega from CFA, composite reliability with SEs,
AVE, HTMT/HTMT2, bifactor decompositions, second-order CFA, multigroup CFA,
measurement invariance, ESEM, IRT GRM, and Mardia normality stay in the
Python pipeline (download `tabs_v2_validation_python.zip` for those).

## What's inside

```
tabs_v2_crp200_spss.sav     <- SPSS native binary worksheet (open with double-click)
tabs_v2_crp200_spss.csv     <- same data, CSV form (for sharing or re-import)
tabs_v2_validation.sps      <- syntax file (Run -> All)
README_SPSS.md              <- detailed walkthrough + expected values
```

## Three quick spot-checks that should match exactly

| Stat | Expected |
|---|---|
| Cronbach's alpha (Barriers, 18 items) | 0.873 |
| Cronbach's alpha (Readiness, 17 items) | 0.917 |
| Cronbach's alpha (Maturity, 8 items) | 0.885 |
| Listwise N (Barriers / Readiness / Maturity) | 192 / 181 / 191 |

If any of these disagree with what SPSS prints, the data import is off
(usually missing-value coding); resolve before interpreting anything else.

See `README_SPSS.md` for the complete expected-value table and the menu
paths for KMO + Bartlett (GUI-only options on the Factor Analysis dialog).
