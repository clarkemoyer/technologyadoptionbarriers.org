# TABS V2 Validation - SPSS Bundle

This zip contains everything an SPSS user needs to independently reproduce
the descriptive + reliability layer of the TABS validation pipeline on the
same frozen N=200 dataset that drives the canonical Python and R analyses.

## Quick start - one double-click

1. Unzip into any folder (Desktop, Documents, anywhere).
2. Double-click the launcher for your operating system:
   - **Windows**: `0_DOUBLE_CLICK_ME_TO_START_WINDOWS.bat`
   - **macOS**: right-click `0_DOUBLE_CLICK_ME_TO_START_MAC.command` -> Open (one-time
     Gatekeeper prompt). After the first run, double-click works.
3. Wait about 60 seconds for the bootstrap blocks to complete.
4. When you see "DONE", open `spv_export.xlsx` in this folder.

The launcher locates SPSS automatically, runs the syntax in production
mode (no GUI clicks required), and writes two result files into the
same folder you extracted the zip to:

- `spv_export.xlsx` - all SPSS tables in Excel format
- `Post_Run_Results.spv` - native SPSS Viewer document (open with SPSS or
  the free IBM SPSS SmartReader)

## Manual fallback (if the launcher cannot find SPSS)

1. Open `tabs_v2_validation.sps` in SPSS (`File -> Open -> Syntax`).
2. `Run -> All`. Output appears in a new Viewer document.
3. The syntax automatically writes `spv_export.xlsx` and `Post_Run_Results.spv`
   into the folder where the .sps file lives.

If SPSS reports "File not found" for the .sav, set the working directory
to the unzipped folder via `Edit -> Options -> File Locations`.

## Targeted SPSS license

Built for IBM SPSS Statistics 24+ with Statistics Base + Regression +
Bootstrapping + Missing Values + Advanced Statistics. Without IBM SPSS
Amos, this bundle covers the descriptive + reliability layer only - CFA
fit indices, McDonald's omega from CFA, composite reliability with SEs,
AVE, HTMT/HTMT2, bifactor decompositions, second-order CFA, multigroup CFA,
measurement invariance, ESEM, IRT GRM, and Mardia normality stay in the
Python pipeline (download `tabs_v2_validation_python.zip` for those).

## What's inside

```
0_DOUBLE_CLICK_ME_TO_START_WINDOWS.bat          <- Windows double-click launcher
0_DOUBLE_CLICK_ME_TO_START_MAC.command      <- macOS double-click launcher
tabs_v2_crp200_spss.sav     <- SPSS native binary worksheet
tabs_v2_crp200_spss.csv     <- same data, CSV form (for re-import elsewhere)
tabs_v2_validation.sps      <- syntax file (auto-runs from the launcher)
README_SPSS.md              <- detailed walkthrough + expected values
README.md                   <- this file
```

## Three quick spot-checks that should match exactly

| Stat | Expected |
|---|---|
| Cronbach's alpha (Barriers, 18 items) | 0.873 |
| Cronbach's alpha (Readiness, 17 items) | 0.917 |
| Cronbach's alpha (Maturity, 8 items) | 0.885 |
| Listwise N (Barriers / Readiness / Maturity) | 192 / 181 / 191 |

If any of these disagree with what SPSS prints, the data import is off
(usually missing-value coding); resolve before interpreting anything else.

See `README_SPSS.md` for the complete expected-value table and the menu
paths for KMO + Bartlett (GUI-only options on the Factor Analysis dialog).
